# Roofline Directory

Contains roofline modeling data and plots.

- `data/`: Raw profiling data and metrics
- `plots/`: Roofline model visualizations
